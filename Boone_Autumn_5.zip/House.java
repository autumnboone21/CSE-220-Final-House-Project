import javafx.application.Application;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.stage.Stage;
import javafx.scene.layout.GridPane;
import javafx.geometry.Pos;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;
import javafx.scene.shape.Arc;
import javafx.scene.shape.ArcType;
import javafx.scene.shape.Line;
import javafx.scene.shape.Circle;
import javafx.scene.shape.Polygon;
import javafx.scene.control.ColorPicker;
import javafx.event.EventHandler;
import javafx.event.Event;

public class House extends Application
{
    public void start(Stage primaryStage) 
    {
        Rectangle grass = new Rectangle();
        grass.setX(0);
        grass.setY(250);
        grass.setWidth(500);
        grass.setHeight(300);
        grass.setFill(Color.GREEN);
        
        Rectangle body = new Rectangle();
        body.setX(150);
        body.setY(150);
        body.setWidth(200);
        body.setHeight(100);
        body.setFill(Color.RED);
        
        Rectangle door = new Rectangle();
        door.setX(225);
        door.setY(175);
        door.setWidth(50);
        door.setHeight(75);
        door.setFill(Color.BLACK);
        
        Circle window1 = new Circle();
        window1.setCenterX(175);
        window1.setCenterY(200);
        window1.setRadius(10);
        window1.setFill(Color.LIGHTBLUE);
        
        Circle window2 = new Circle();
        window2.setCenterX(325);
        window2.setCenterY(200);
        window2.setRadius(10);
        window2.setFill(Color.LIGHTBLUE);
        
        Polygon roof = new Polygon();
        roof.getPoints().addAll(new Double[]{
            150.0, 150.0,
            250.0, 50.0,
            350.0, 150.0
        });
        roof.setFill(Color.BROWN);
        
        ColorPicker cp = new ColorPicker(Color.RED);
        
        cp.setOnAction(new EventHandler() {
            public void handle(Event t) {
                Color c = cp.getValue();
                body.setFill(c);            
            }
        });
            
        Group root = new Group(grass, body, door, window1, window2, roof, cp);
        Scene scene = new Scene(root, 500, 500, Color.CYAN);
             
        primaryStage.setTitle("House");
        primaryStage.setScene(scene);
        primaryStage.show();
    }
}
